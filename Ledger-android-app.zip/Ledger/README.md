# Ledger — Daily Expense Tracker (Android)

A native Android app built with Kotlin + Jetpack Compose + Room.

## Features
- **Note**: quick form to log an expense (amount, category, optional note) — saved with today's date
- **Track**: month-by-month list of expenses, swipe between months, delete any entry
- **Report**: spending broken down by category with proportional bars, per selected month
- All data is stored locally on-device in a Room (SQLite) database — nothing leaves the phone

## How to open and run it
1. Install [Android Studio](https://developer.android.com/studio) (Ladybug or newer) if you don't have it.
2. Unzip this project, then in Android Studio choose **File > Open** and select the unzipped `Ledger` folder.
3. Let Gradle sync — it will download the required SDK/build tools/dependencies automatically (needs internet the first time).
4. Plug in a phone (with USB debugging on) or start an emulator, then hit **Run ▶**.
5. Minimum supported version: Android 8.0 (API 26).

## Building an APK without Android Studio (GitHub Actions)
This project includes `.github/workflows/build.yml`, which builds a debug APK automatically
on GitHub's servers — useful if you don't want to install Android Studio at all.

1. Create a new **public or private** repo on [github.com](https://github.com) (e.g. `ledger-app`).
2. Upload the contents of this unzipped `Ledger` folder to that repo. Easiest way with no
   command line: on the repo page, click **Add file > Upload files**, drag in everything from
   the unzipped folder (keep the folder structure), and commit.
3. Go to the repo's **Actions** tab. A workflow run should start automatically (or click
   **Build APK > Run workflow** to trigger it manually).
4. Wait for the green checkmark (a couple of minutes), then open that run. You'll see two
   downloadable artifacts:
   - **ledger-release-apk** — optimized (code-shrunk via R8, unused resources stripped, no
     debug overhead). This is the one to install for normal use — it runs noticeably faster
     and takes less space.
   - **ledger-debug-apk** — unoptimized, only useful if you're debugging in Android Studio.
5. Download **ledger-release-apk**, unzip it to get `app-release.apk`.
6. Transfer `app-release.apk` to your phone (email it to yourself, use Google Drive, USB transfer,
   etc.), open it from a file manager, and tap **Install**. Android will ask you to allow installs
   from that source the first time — approve it, then install. (If you already installed the
   debug build earlier, it'll sit alongside this one since it uses a different app ID — feel
   free to uninstall the debug one.)

Both builds are signed with Android's default debug key, which is fine for installing on your
own phone but not accepted by the Play Store. Publishing there needs your own private release
signing key — a separate step if you ever want to go that route.

## If Gradle sync flags version mismatches
Android Studio periodically bumps the recommended Android Gradle Plugin / Kotlin versions. If sync
complains, accept the **Upgrade Assistant** prompt it offers — it will update `build.gradle.kts`
and `gradle-wrapper.properties` for you.

## Project layout
```
app/src/main/java/com/ledger/app/
  data/          Room entity, DAO, database, repository
  viewmodel/     ExpenseViewModel (state + business logic)
  ui/            Compose screens (Track, Report) + theme
  MainActivity.kt
```

## Extending it
- Swap the category list in `TrackScreen.kt` for your own categories.
- Add a date picker if you want to log expenses for past days (currently every new entry uses today's date).
- Add CSV/PDF export from the Report screen for sharing reports outside the app.
