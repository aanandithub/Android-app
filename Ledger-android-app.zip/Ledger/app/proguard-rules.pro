# Room generates its implementation classes at compile time; nothing extra needed for
# entities/DAOs used the normal way, but keep annotations just in case of reflection.
-keepattributes *Annotation*

# Keep Room's generated database/DAO implementations.
-keep class com.ledger.app.data.** { *; }
