package com.ledger.app.ui.theme

import androidx.compose.ui.graphics.Color

val ForestDark = Color(0xFF1F2E28)
val ForestDeep = Color(0xFF12201A)
val Paper = Color(0xFFFFFFFF)
val PaperBg = Color(0xFFF7F4EC)
val Brass = Color(0xFFA9762F)
val BrassLight = Color(0xFFD2A24C)
val Debit = Color(0xFF8B3A3A)
val DebitDark = Color(0xFFD98080)
val CreamText = Color(0xFFEAE6DA)
