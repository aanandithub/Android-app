package com.ledger.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = Brass,
    background = PaperBg,
    surface = Paper,
    onPrimary = Paper,
    onBackground = ForestDark,
    onSurface = ForestDark,
    error = Debit
)

private val DarkColors = darkColorScheme(
    primary = BrassLight,
    background = ForestDeep,
    surface = ForestDark,
    onPrimary = ForestDeep,
    onBackground = CreamText,
    onSurface = CreamText,
    error = DebitDark
)

@Composable
fun LedgerTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, typography = LedgerTypography, content = content)
}
