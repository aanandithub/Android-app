package com.ledger.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.ledger.app.viewmodel.ExpenseViewModel

@Composable
fun ReportScreen(viewModel: ExpenseViewModel) {
    val entries by viewModel.monthExpenses.collectAsState()
    val month by viewModel.selectedMonth.collectAsState()

    val byCategory = entries.groupBy { it.category }
        .mapValues { (_, list) -> list.sumOf { it.amount } }
        .toList()
        .sortedByDescending { it.second }

    val maxVal = byCategory.maxOfOrNull { it.second } ?: 0.0

    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Text(
                "REPORT \u2014 " + month.month.name.lowercase().replaceFirstChar { it.uppercase() } + " " + month.year,
                style = MaterialTheme.typography.labelSmall
            )
            Spacer(Modifier.height(16.dp))
        }
        if (byCategory.isEmpty()) {
            item { Text("Nothing to report yet.", style = MaterialTheme.typography.bodyMedium) }
        } else {
            items(byCategory) { (cat, amt) ->
                Column(Modifier.padding(vertical = 8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(cat)
                        Text("\u20b9%.0f".format(amt))
                    }
                    Spacer(Modifier.height(4.dp))
                    val fraction = if (maxVal > 0) (amt / maxVal).toFloat() else 0f
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(fraction)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(MaterialTheme.colorScheme.primary)
                        )
                    }
                }
            }
        }
    }
}
