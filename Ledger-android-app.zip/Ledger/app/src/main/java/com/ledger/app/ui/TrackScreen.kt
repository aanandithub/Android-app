package com.ledger.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Divider
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ledger.app.viewmodel.ExpenseViewModel
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle as JTextStyle
import java.util.Locale

private val categories = listOf("Food", "Transport", "Groceries", "Bills", "Shopping", "Health", "Entertainment", "Other")

@Composable
fun TrackScreen(viewModel: ExpenseViewModel) {
    val month by viewModel.selectedMonth.collectAsState()
    val entries by viewModel.monthExpenses.collectAsState()
    val total = entries.sumOf { it.amount }

    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(categories.first()) }
    var note by remember { mutableStateOf("") }
    var categoryExpanded by remember { mutableStateOf(false) }
    var showForm by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item { Spacer(Modifier.height(16.dp)) }

        item {
            Card {
                Column(Modifier.padding(20.dp)) {
                    Text("SPENT THIS MONTH", style = MaterialTheme.typography.labelSmall)
                    Text("\u20b9%.0f".format(total), style = MaterialTheme.typography.headlineMedium)
                    Row(
                        Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { viewModel.prevMonth() }) { Text("\u2039") }
                        Text(
                            month.month.getDisplayName(JTextStyle.FULL, Locale.getDefault()) + " " + month.year,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        TextButton(onClick = { viewModel.nextMonth() }) { Text("\u203a") }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        item {
            OutlinedButton(onClick = { showForm = !showForm }, modifier = Modifier.fillMaxWidth()) {
                Text(if (showForm) "Cancel" else "+ Add expense")
            }
            Spacer(Modifier.height(8.dp))
        }

        if (showForm) {
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = amount, onValueChange = { amount = it },
                            label = { Text("Amount") }, modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        ExposedDropdownMenuBox(expanded = categoryExpanded, onExpandedChange = { categoryExpanded = it }) {
                            OutlinedTextField(
                                value = category, onValueChange = {}, readOnly = true,
                                label = { Text("Category") },
                                modifier = Modifier.fillMaxWidth().menuAnchor(),
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) }
                            )
                            androidx.compose.material3.ExposedDropdownMenu(
                                expanded = categoryExpanded,
                                onDismissRequest = { categoryExpanded = false }
                            ) {
                                categories.forEach {
                                    DropdownMenuItem(text = { Text(it) }, onClick = { category = it; categoryExpanded = false })
                                }
                            }
                        }
                        OutlinedTextField(
                            value = note, onValueChange = { note = it },
                            label = { Text("Note (optional)") }, modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Button(
                            onClick = {
                                val value = amount.toDoubleOrNull()
                                if (value != null && value > 0) {
                                    val today = LocalDate.now().format(DateTimeFormatter.ISO_DATE)
                                    viewModel.addExpense(value, category, today, note.trim())
                                    amount = ""; note = ""; showForm = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Save") }
                    }
                }
                Spacer(Modifier.height(20.dp))
            }
        }

        item { Text("ENTRIES", style = MaterialTheme.typography.labelSmall) }
        item { Spacer(Modifier.height(8.dp)) }

        if (entries.isEmpty()) {
            item { Text("No expenses logged this month yet.", style = MaterialTheme.typography.bodyMedium) }
        } else {
            items(entries, key = { it.id }) { e ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(e.category, fontWeight = FontWeight.Medium)
                        if (e.note.isNotBlank()) Text(e.note, style = MaterialTheme.typography.bodyMedium)
                    }
                    Text("-\u20b9%.0f".format(e.amount), color = MaterialTheme.colorScheme.error)
                    IconButton(onClick = { viewModel.deleteExpense(e) }) {
                        Icon(Icons.Filled.Close, contentDescription = "Delete")
                    }
                }
                Divider()
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
