package com.ledger.app.data

import kotlinx.coroutines.flow.Flow

class ExpenseRepository(private val dao: ExpenseDao) {
    val allExpenses: Flow<List<Expense>> = dao.getAll()

    suspend fun add(expense: Expense) = dao.insert(expense)

    suspend fun remove(expense: Expense) = dao.delete(expense)
}
