package com.ledger.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ledger.app.data.Expense
import com.ledger.app.data.ExpenseDatabase
import com.ledger.app.data.ExpenseRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.YearMonth
import java.time.format.DateTimeFormatter

class ExpenseViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ExpenseRepository(ExpenseDatabase.getInstance(app).expenseDao())

    private val _selectedMonth = MutableStateFlow(YearMonth.now())
    val selectedMonth: StateFlow<YearMonth> = _selectedMonth

    val allExpenses: StateFlow<List<Expense>> =
        repo.allExpenses.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val monthExpenses: StateFlow<List<Expense>> = combine(allExpenses, selectedMonth) { list, month ->
        val prefix = month.format(DateTimeFormatter.ofPattern("yyyy-MM"))
        list.filter { it.date.startsWith(prefix) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun nextMonth() { _selectedMonth.value = _selectedMonth.value.plusMonths(1) }
    fun prevMonth() { _selectedMonth.value = _selectedMonth.value.minusMonths(1) }

    fun addExpense(amount: Double, category: String, date: String, note: String) {
        viewModelScope.launch {
            repo.add(Expense(amount = amount, category = category, date = date, note = note))
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch { repo.remove(expense) }
    }
}
